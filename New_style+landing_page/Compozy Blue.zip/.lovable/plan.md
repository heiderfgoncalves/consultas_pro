
# Plano: Landing institucional do Consultas PRO — estilo Compozy em azul

Mudança de rumo: **só a landing por enquanto**, direto, inspirada nos prints. Sem importar app, sem refazer sistema. Depois do seu OK, incorporo no app.

## Identidade visual (travada)
- **Estética**: dark-first, console técnico, denso, brackets `[ ]`, eyebrows em mono uppercase com tracking largo, divisores 1px com gradiente, cantos em "L" tipo HUD (igual ao print do COMPOZY.PIPELINE).
- **Azul de marca**: `#0A84FF` light / `#2196FF` dark — substitui 100% o verde neon do Compozy. Único acento, usado com parcimônia (badges "RUNNING", pulses, highlights de etapas, números das listas).
- **Neutros**: zinc-950 fundo, zinc-925 superfícies, zinc-900 bordas, zinc-400/500 texto secundário.
- **Tipografia**: Geist Sans (display/body) + Geist Mono (eyebrows, terminais, badges, labels técnicos). Display 56-72px com tracking -0.03em, corpo 14-15px, mono 10-11px uppercase tracking 0.2em.
- **Espaçamento**: compacto (py-20 entre seções, max-w-7xl, gap-4 entre cards). Nada de respiração exagerada.

## Animações ("nem sutil, nem exagerado")
Tudo com `framer-motion` + CSS. Aplicação:
- **Hero**: fade-up sequencial (eyebrow → headline → sub → CTAs → mockup), duração 600ms, stagger 80ms.
- **Pipeline horizontal de 7 etapas** (igual print 2): linha que se desenha da esquerda pra direita ao entrar no viewport, ícones aparecem 1 a 1, número badge faz pop, etapa ativa pulsa em azul.
- **Cards de feature**: hover-lift 2px + border azul translúcida + glow sutil; entrada com fade-up no scroll, stagger 60ms entre cards do mesmo grid.
- **Terminal "// OUTPUT"** (igual print 1, bloco inferior direito): linhas de log digitando em sequência com cursor piscando, loop infinito reiniciando a cada 6s.
- **Badges "RUNNING"**: ponto verde-azul com `ping` pulse.
- **Contadores de métricas**: animação de 0 → valor final em 1.2s ao entrar no viewport.
- **CTA final**: border-beam azul rodando pelo perímetro do card.
- **Gradient mesh**: blob azul no hero respirando lentamente (12s loop).
- **Logos / abas que trocam**: tabs do "STRUCTURED PIPELINE" com indicador deslizante (layoutId).

## Estrutura da landing (preenchida com info real das docs)

1. **Top nav slim** — logo `[ CONSULTAS_PRO ]` + links (Plataforma, Integrações, Templates, Preços, Docs) + "Entrar" + CTA "Começar grátis".

2. **Hero**
   - Eyebrow chip `[ v2.0 — PIPELINE ENGINE ]` com dot pulsante.
   - Headline: **"Relatórios de crédito que você desenha. Em segundos."** (palavra "desenha" em azul gradient).
   - Sub: "SaaS modular para consulta de dívidas, cadastro e crédito. Monte o layout do seu relatório, escolha os blocos que importa pagar, e emita com saldo em carteira — sem pacotes engessados."
   - CTAs: "Começar grátis" (sólido azul) + "Ver documentação →" (ghost).
   - Linha de métricas inline embaixo: `40+ FORNECEDORES • 9 TIPOS DE CONSULTA • <250ms LATÊNCIA`.

3. **Hero Mockup** — réplica do card "COMPOZY.PIPELINE" adaptado:
   - Frame com cantos em L, header `[ >> CONSULTAS.PIPELINE ]` + badge "RUNNING" azul.
   - Sub-header `MOTOR DE EMISSÃO DE RELATÓRIOS`.
   - Pipeline horizontal animado de 6 ícones: **TEMPLATE → DADOS → DE-PARA → FÓRMULAS → EMISSÃO → ENTREGA**.
   - Footer do card: `PROVEDORES 40+ • TIPOS 9 • Local-First` (chip lateral).

4. **Bento split (igual print 1 inferior)** — 2 colunas:
   - **Esquerda — `WORKFLOW`**: título "PIPELINE ESTRUTURADO / EM 5 ETAPAS" com "5 ETAPAS" em azul. Lista numerada vertical com linha conectora animada:
     - 01 PROVEDORES — conecta APIs externas
     - 02 CONSULTAS — define produtos consumíveis
     - 03 TIPOS — motor de-para flat normalization
     - 04 TEMPLATES — drawer drag-and-drop com `math()`
     - 05 EMISSÃO — fila BullMQ + ledger transacional
   - Item ativo (03) destacado em quadrado azul.
   - Footer chip: `MODO: PROD` / `FLAT_FIRST`.
   - **Direita — `INTEGRAÇÕES`**: número grande "40+", grid 2x4 de mini-cards com ícones de provedores (SOLLOS, etc.), abaixo stats `TIPOS 9 built-in / ETAPAS 5 / DEPS Zero`.
   - Abaixo: **CONSULTAS // OUTPUT** — terminal animado com logs reais do fluxo:
     ```
     [10:00:08] EMIT  Enfileirando job de emissão...
     [10:00:10] FETCH Consultando 4 provedores em paralelo...
     [10:00:12] MAP   Aplicando de-para FLAT → TEMPLATE
     [10:00:14] LEDGER Débito R$ 14,77 confirmado
     [10:00:15] DONE  PDF gerado em 1.2s
     ```

5. **Pipeline horizontal de 7 etapas** (igual print 2, full-width):
   IDEIA → CONSULTA → DE-PARA → TEMPLATE → EMISSÃO → ENTREGA → AUDITORIA. Linha conectora desenhando, badges numerados, descrições curtas embaixo.

6. **"100% LOCAL OU CLOUD" (igual print 3)** — split 50/50:
   - Esquerda: card com 4 sub-cards (SEU TERMINAL / API ENGINE / IA AGENTS / SEUS DADOS) com bolinhas azul pulsantes.
   - Direita: "06 — WHITE-LABEL" + "Seu produto, sua marca, seu domínio." + bullets (multi-tenant, domínio customizado, tema próprio, isolamento de dados).

7. **Bento de diferenciais** (3x2 mistos):
   - Templates Drawer (drag-and-drop) [grande]
   - Motor `math()` com purificação BR
   - LGPD + Auditoria
   - 5 perfis de acesso (Admin/Master/Gestor/Operador/Indiv.)
   - Carteira compartilhada
   - White-label completo

8. **"COMECE AQUI / Instale em segundos" (igual print 4)** — 4 cards de início:
   - WEB (RECOMENDADO) → `app.consultaspro.com`
   - API REST → `curl https://api.consultaspro.com/v1/emit`
   - SDK Node → `npm install @consultas-pro/sdk`
   - WHITE-LABEL → "Fale com vendas"
   Botão copy nos snippets.

9. **Métricas animadas** — 4 números: 40+ fornecedores / 9 tipos / 99.9% uptime / <250ms latência.

10. **FAQ** accordion 5-6 itens (LGPD, white-label, tipos suportados, integração, preços).

11. **CTA final** — card com border-beam azul: "Pronto para emitir relatórios sob medida?" + 2 CTAs.

12. **Footer 4 colunas** + linha de créditos com mono.

## Arquivos a criar/editar (apenas isto)
- `src/styles.css` — tokens dark-first + paleta azul + fontes Geist + utilitárias (`.hud-corner`, `.eyebrow`, `.terminal-line`).
- `src/routes/__root.tsx` — registrar fontes Geist (via @fontsource), `dark` class no html.
- `src/routes/index.tsx` — landing montada a partir das seções abaixo.
- `src/components/landing/Nav.tsx`
- `src/components/landing/Hero.tsx`
- `src/components/landing/PipelineCard.tsx` (réplica do "COMPOZY.PIPELINE")
- `src/components/landing/WorkflowSplit.tsx` (réplica do split print 1)
- `src/components/landing/TerminalOutput.tsx` (logs animados)
- `src/components/landing/SevenSteps.tsx`
- `src/components/landing/LocalOrCloud.tsx`
- `src/components/landing/FeaturesBento.tsx`
- `src/components/landing/StartHere.tsx`
- `src/components/landing/Metrics.tsx`
- `src/components/landing/FAQ.tsx`
- `src/components/landing/FinalCTA.tsx`
- `src/components/landing/Footer.tsx`
- `src/components/landing/primitives.tsx` (HUDFrame, Eyebrow, BorderBeam, FadeUp)
- Instalar: `framer-motion`, `@fontsource/geist-sans`, `@fontsource/geist-mono`, `lucide-react`.

## Fora deste turno
- Não importar `frontend/` ainda.
- Não conectar backend ngrok (landing é estática).
- Não migrar páginas internas, não tocar em login/dashboard, não criar sistema de temas trocáveis.

## O que entrego
Landing dark, densa, animada, com a mesma "vibe Compozy" mas 100% azul e em português, preenchida com o vocabulário real do Consultas PRO (pipeline, de-para, templates drawer, math(), ledger, white-label, 5 perfis).

## Próximo passo após você ver
Você dá OK ou pede ajustes pontuais. Quando aprovar, abro a fase 2: incorporar o tema globalmente no `frontend/` e portar páginas internas.
