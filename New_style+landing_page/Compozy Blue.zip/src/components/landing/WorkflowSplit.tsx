import { motion } from "framer-motion";
import { BracketLabel, FadeUp, HUDFrame } from "./primitives";
import { TerminalOutput } from "./TerminalOutput";
import { Grid3x3 } from "lucide-react";

const stages = [
  { n: "01", title: "PROVEDORES", desc: "Conecta APIs externas (SOLLOS, Serasa, Boa Vista, +37)" },
  { n: "02", title: "CONSULTAS", desc: "Define produtos consumíveis com preço por bloco" },
  { n: "03", title: "TIPOS", desc: "Motor de-para FLAT — normaliza payloads heterogêneos", active: true },
  { n: "04", title: "TEMPLATES", desc: "Drawer drag-and-drop com motor math() BR" },
  { n: "05", title: "EMISSÃO", desc: "Fila BullMQ + ledger transacional com estorno" },
];

const providers = ["SOLLOS", "SERASA", "BOA_VISTA", "SCPC", "SPC", "CONSULTAS+", "ASAAS", "+33"];

export function WorkflowSplit() {
  return (
    <section id="plataforma" className="relative py-24">
      <div className="mx-auto max-w-7xl px-6">
        <div className="grid lg:grid-cols-2 gap-5">
          {/* Left — Workflow */}
          <FadeUp>
            <HUDFrame className="p-6 md:p-8 h-full">
              <BracketLabel>WORKFLOW</BracketLabel>
              <h3 className="mt-4 text-3xl md:text-4xl font-medium tracking-[-0.03em]">
                PIPELINE<br />
                <span className="brand-text">ESTRUTURADO</span>
              </h3>
              <p className="mt-3 text-sm text-muted-foreground max-w-sm">
                Da consulta crua ao PDF entregue em 5 etapas auditáveis, com saldo em carteira e estorno automático em falhas parciais.
              </p>

              <div className="mt-8 relative">
                <div className="absolute left-[14px] top-2 bottom-2 w-px bg-hairline" />
                <motion.div
                  initial={{ height: 0 }}
                  animate={{ height: "100%" }}
                  transition={{ duration: 1.6, ease: "easeInOut" }}
                  className="absolute left-[14px] top-2 w-px bg-gradient-to-b from-brand via-brand to-transparent"
                />
                <ul className="space-y-5">
                  {stages.map((s, i) => (
                    <motion.li
                      key={s.n}
                      initial={{ opacity: 0, x: 8 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: 0.1 + i * 0.1, duration: 0.4 }}
                      className="relative flex items-start gap-4 pl-8"
                    >
                      <div
                        className={`absolute left-0 top-0 flex h-7 w-7 items-center justify-center rounded-sm border ${
                          s.active
                            ? "border-brand bg-brand/15 text-brand shadow-[0_0_24px_-4px_var(--color-brand)]"
                            : "border-hairline bg-surface text-muted-foreground"
                        } mono text-[10px]`}
                      >
                        {s.n}
                      </div>
                      <div>
                        <div className={`mono text-[12px] tracking-[0.18em] uppercase ${s.active ? "text-foreground" : "text-foreground/85"}`}>
                          {s.title}
                        </div>
                        <div className="mt-1 text-[13px] text-muted-foreground">{s.desc}</div>
                      </div>
                    </motion.li>
                  ))}
                </ul>
              </div>

              <div className="mt-8 flex items-center justify-between border-t border-hairline pt-4 mono text-[10px] tracking-[0.18em] uppercase">
                <span className="text-muted-foreground">MODO: <span className="text-foreground">PROD</span></span>
                <span className="rounded-sm border border-hairline px-2 py-1 text-brand">FLAT_FIRST</span>
              </div>
            </HUDFrame>
          </FadeUp>

          {/* Right — Integrações + Terminal */}
          <div className="flex flex-col gap-5">
            <FadeUp delay={0.1}>
              <HUDFrame className="p-6 md:p-8">
                <div className="flex items-start justify-between">
                  <BracketLabel>INTEGRAÇÕES</BracketLabel>
                  <Grid3x3 className="h-4 w-4 text-muted-foreground" />
                </div>
                <div className="mt-5 flex items-end gap-4">
                  <span className="text-5xl md:text-6xl font-medium tracking-[-0.03em] text-foreground">40+</span>
                  <span className="mb-2 text-sm text-muted-foreground">fornecedores integrados via SDK unificado</span>
                </div>

                <div className="mt-6 grid grid-cols-4 gap-2">
                  {providers.map((p, i) => (
                    <motion.div
                      key={p}
                      initial={{ opacity: 0, scale: 0.95 }}
                      animate={{ opacity: 1, scale: 1 }}
                      transition={{ delay: i * 0.05, duration: 0.3 }}
                      className="flex h-12 items-center justify-center rounded-sm border border-hairline bg-surface/60 mono text-[10px] tracking-[0.14em] uppercase text-foreground/80 hover:border-brand/50 hover:text-brand transition-colors"
                    >
                      {p}
                    </motion.div>
                  ))}
                </div>

                <div className="mt-6 grid grid-cols-3 gap-4 border-t border-hairline pt-4">
                  <Stat label="TIPOS" value="9 built-in" />
                  <Stat label="ETAPAS" value="5 stages" />
                  <Stat label="DEPS" value="Zero" />
                </div>
              </HUDFrame>
            </FadeUp>

            <FadeUp delay={0.2}>
              <TerminalOutput />
            </FadeUp>
          </div>
        </div>
      </div>
    </section>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <div className="mono text-[10px] tracking-[0.18em] uppercase text-muted-foreground">{label}</div>
      <div className="mono text-[13px] text-brand mt-1">{value}</div>
    </div>
  );
}

