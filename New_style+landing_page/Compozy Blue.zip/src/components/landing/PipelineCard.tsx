import { motion } from "framer-motion";
import { FileText, Database, Shuffle, Calculator, Send, FileCheck } from "lucide-react";
import { PulseDot } from "./primitives";

const steps = [
  { icon: FileText, label: "TEMPLATE" },
  { icon: Database, label: "DADOS" },
  { icon: Shuffle, label: "DE-PARA" },
  { icon: Calculator, label: "FÓRMULAS" },
  { icon: Send, label: "EMISSÃO" },
  { icon: FileCheck, label: "ENTREGA" },
];

export function PipelineCard() {
  return (
    <div>
      {/* Header */}
      <div className="flex items-start justify-between">
        <div>
          <div className="mono text-[11px] tracking-[0.18em] uppercase text-brand">
            &gt;&gt; CONSULTAS.PIPELINE
          </div>
          <div className="mt-1 mono text-[11px] tracking-[0.18em] uppercase text-muted-foreground">
            MOTOR DE EMISSÃO DE RELATÓRIOS
          </div>
        </div>
        <div className="flex items-center gap-3">
          <Equalizer />
          <span className="inline-flex items-center gap-1.5 rounded-sm border border-brand/40 bg-brand/10 px-2 py-0.5 mono text-[10px] tracking-[0.18em] uppercase text-brand">
            <PulseDot />
            RUNNING
          </span>
        </div>
      </div>

      {/* Pipeline rail */}
      <div className="relative mt-8 rounded-md border border-hairline bg-background/40 p-6 md:p-8">
        <svg className="absolute left-8 right-8 top-1/2 h-px -translate-y-1/2 hidden md:block" viewBox="0 0 100 1" preserveAspectRatio="none" style={{ width: "calc(100% - 4rem)" }}>
          <motion.line
            x1="0" y1="0.5" x2="100" y2="0.5"
            stroke="var(--color-brand)" strokeWidth="0.4" strokeDasharray="2 2"
            initial={{ pathLength: 0 }}
            animate={{ pathLength: 1 }}
            transition={{ duration: 1.8, ease: "easeInOut" }}
          />
        </svg>
        <div className="relative grid grid-cols-3 md:grid-cols-6 gap-y-6">
          {steps.map((s, i) => {
            const Icon = s.icon;
            const active = i === 2;
            return (
              <motion.div
                key={s.label}
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.15 + i * 0.12, duration: 0.4 }}
                className="flex flex-col items-center gap-3"
              >
                <div
                  className={`relative flex h-11 w-11 items-center justify-center rounded-sm border ${
                    active ? "border-brand bg-brand/15 text-brand" : "border-hairline bg-surface text-muted-foreground"
                  }`}
                >
                  <Icon className="h-4 w-4" />
                  {active && (
                    <span className="absolute -inset-1 rounded-sm border border-brand/40 animate-pulse" />
                  )}
                </div>
                <div className="mono text-[10px] tracking-[0.2em] uppercase text-foreground/80">{s.label}</div>
              </motion.div>
            );
          })}
        </div>
      </div>

      {/* Footer stats */}
      <div className="mt-6 flex flex-wrap items-end justify-between gap-4 border-t border-hairline pt-4">
        <div className="flex gap-8">
          <Stat label="PROVEDORES" value="40+" />
          <Stat label="TIPOS" value="9" />
          <Stat label="UPTIME" value="99.9%" />
        </div>
        <span className="mono text-[10px] tracking-[0.18em] uppercase border border-hairline rounded-sm px-2 py-1 text-muted-foreground">
          ◆ Local-First
        </span>
      </div>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <div className="mono text-[10px] tracking-[0.2em] uppercase text-muted-foreground">{label}</div>
      <div className="mono text-lg text-brand mt-0.5">{value}</div>
    </div>
  );
}

function Equalizer() {
  return (
    <div className="flex items-end gap-0.5 h-4">
      {[0.4, 0.7, 0.9, 0.5, 0.8, 0.6, 0.3, 0.9, 0.5].map((h, i) => (
        <motion.span
          key={i}
          className="w-0.5 bg-brand/70"
          initial={{ height: 2 }}
          animate={{ height: [2, h * 16, 2] }}
          transition={{ duration: 1.1, repeat: Infinity, delay: i * 0.08, ease: "easeInOut" }}
        />
      ))}
    </div>
  );
}

