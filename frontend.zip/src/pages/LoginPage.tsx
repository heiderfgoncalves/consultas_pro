import { useEffect, useState } from "react";
import { Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Eye, EyeOff, ArrowRight } from 'lucide-react';
import { useAuthStore } from '@/stores/authStore';
import { ApiError } from '@/lib/api';
import { toast } from 'sonner';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { HeroTypewriterHeading } from '@/components/branding/HeroTypewriterHeading';
import { getHeroTypewriterCursorStartMs } from '@/lib/hero-typewriter';
import { BackgroundRippleEffect } from '@/components/ui/background-ripple-effect';
import { PointerHighlight } from '@/components/ui/pointer-highlight';
import { useSubTheme } from '@/hooks/use-subtheme';


export default function LoginPage() {
  const { subTheme } = useSubTheme();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [remember, setRemember] = useState(false);
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();
  const { login, hydrated, isAuthenticated } = useAuthStore();

  useEffect(() => {
    if (hydrated && isAuthenticated) {
      navigate("/dashboard", { replace: true });
    }
  }, [hydrated, isAuthenticated, navigate]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      await login(email, password);
      navigate('/dashboard');
    } catch (err) {
      const msg = err instanceof ApiError ? err.message : 'Não foi possível entrar';
      toast.error(msg);
    } finally {
      setLoading(false);
    }
  };

  if (!hydrated) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div
          className="h-9 w-9 rounded-full border-2 border-muted-foreground/25 border-t-primary animate-spin"
          aria-hidden
        />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex">
      {/* Left - Branding */}
      <div className="hidden min-h-screen lg:flex lg:w-1/2 gradient-primary relative overflow-hidden">
        <div className="absolute inset-0 z-0">
          <BackgroundRippleEffect
            cover
            coverPosition="top-left"
            rows={13}
            cols={10}
            cellSize={60}
            masked={false}
            className="[--cell-border-color:hsl(var(--primary-foreground)_/_0.18)] [--cell-fill-color:hsl(var(--primary-foreground)_/_0.06)] [--cell-shadow-color:hsl(var(--primary-foreground)_/_0.12)]"
            gridClassName="opacity-50"
          />
        </div>
        <div className="absolute inset-0 z-[1] opacity-10 pointer-events-none">
          <div className="absolute top-20 left-20 w-64 h-64 rounded-full bg-primary-foreground blur-3xl" />
          <div className="absolute bottom-20 right-20 w-96 h-96 rounded-full bg-primary-foreground blur-3xl" />
        </div>
        <div className="relative z-10 flex w-full items-center justify-center px-16 py-14 pointer-events-none">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="flex w-full max-w-[620px] flex-col"
          >
            <HeroTypewriterHeading className="text-4xl font-bold text-primary-foreground leading-tight mb-4" />
            <div className="flex flex-col gap-5">
              <div className="text-lg text-primary-foreground/70 max-w-md leading-relaxed">
                Monte seu relatório{" "}
                <PointerHighlight
                  effectDelaySec={getHeroTypewriterCursorStartMs() / 1000}
                  rectangleClassName="border-primary-foreground/40"
                  pointerClassName="text-primary-foreground"
                >
                  <span className="relative z-[1] font-medium text-primary-foreground/90">personalizado</span>
                </PointerHighlight>
                , escolha os blocos de dados que precisa e pague apenas pelo que usar.
              </div>
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.6 }}
                className="flex flex-wrap items-center gap-3"
              >
                {['SPC', 'Serasa', 'Score', 'Bacen', '+8'].map((item, i) => (
                  <div
                    key={i}
                    className="rounded-full border border-primary-foreground/20 bg-primary-foreground/5 px-4 py-1.5 text-center text-sm text-primary-foreground/70 backdrop-blur-[2px]"
                  >
                    {item}
                  </div>
                ))}
              </motion.div>
            </div>
          </motion.div>
        </div>
      </div>

      {/* Right - Form */}
      <div className="relative flex min-h-screen flex-1 items-center justify-center bg-background px-6 py-12 overflow-hidden">
        {/* Fundo sutil de grade e iluminação azul elástica estilo Compozy */}
        <div className="absolute inset-0 -z-10 pointer-events-none" aria-hidden="true">
          <div className="absolute inset-0 compozy-grid-bg opacity-[0.25] dark:opacity-[0.85]" />
          <div className="absolute top-[20%] left-[20%] w-[60%] h-[60%] bg-[radial-gradient(circle_at_center,hsla(212,95%,56%,0.04),transparent_65%)]" />
        </div>

        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.35, ease: 'easeOut' }}
          className="relative z-10 w-full max-w-[380px] border border-border/40 bg-card/35 backdrop-blur-md px-6 py-8 rounded-xl shadow-lg"
        >
          <div className="mb-6 flex flex-col items-center text-center select-none">
            <img
              src="/logo.png"
              alt="Consultas PRO"
              className="mb-2 h-16 w-auto object-contain sm:h-20"
            />
            <div className="mt-1 flex items-center gap-1.5 font-mono text-[9px] text-primary tracking-[0.15em] uppercase">
              <span className="w-1 h-1 rounded-full bg-primary animate-pulse" /> Security Access Panel
            </div>
            <p className="text-[11px] text-muted-foreground mt-1.5">Acesse sua credencial para continuar</p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-1.5">
              <Label htmlFor="email" className="text-xs text-muted-foreground font-medium">E-mail</Label>
              <Input
                id="email"
                name="email"
                type="email"
                placeholder="seu@email.com.br"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                autoComplete="email"
                spellCheck={false}
                required
                className="h-9.5 text-xs"
              />
            </div>

            <div className="space-y-1.5">
              <div className="flex items-center justify-between">
                <Label htmlFor="password" className="text-xs text-muted-foreground font-medium">Senha</Label>
                <Link to="/recuperar-acesso" className="text-[10px] text-primary hover:underline">
                  Esqueci minha senha
                </Link>
              </div>
              <div className="relative">
                <Input
                  id="password"
                  name="password"
                  type={showPassword ? 'text' : 'password'}
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  autoComplete={showPassword ? 'current-password' : 'current-password'}
                  required
                  className="h-9.5 pr-10 text-xs"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  aria-label={showPassword ? 'Ocultar senha' : 'Mostrar senha'}
                  className="absolute right-2 top-1/2 -translate-y-1/2 rounded-md p-1.5 text-muted-foreground transition-[color,transform] duration-150 hover:bg-accent hover:text-foreground active:scale-90"
                >
                  {showPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                </button>
              </div>
            </div>

            <div className="flex items-center gap-2 py-1">
              <Checkbox id="remember" checked={remember} onCheckedChange={(v) => setRemember(!!v)} />
              <Label htmlFor="remember" className="text-[11px] font-normal text-muted-foreground cursor-pointer select-none">
                Lembrar meu acesso
              </Label>
            </div>

            <Button type="submit" className="w-full h-9.5 text-xs tracking-wide gradient-primary text-primary-foreground font-medium compozy-btn-glow" disabled={loading}>
              {loading ? (
                <div className="w-4 h-4 border-2 border-primary-foreground/30 border-t-primary-foreground rounded-full animate-spin" />
              ) : (
                <>Entrar <ArrowRight className="w-3.5 h-3.5 ml-1.5" /></>
              )}
            </Button>
          </form>

          <p className="text-[11px] text-center text-muted-foreground mt-6">
            Ainda não tem conta?{' '}
            <Link to="/cadastro" className="text-primary font-medium hover:underline">
              Criar conta
            </Link>
          </p>
        </motion.div>
      </div>
    </div>
  );
}
