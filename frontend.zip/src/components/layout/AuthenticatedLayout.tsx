import { Outlet, Navigate, useLocation } from 'react-router-dom';
import AppSidebar from './AppSidebar';
import TopBar from './TopBar';
import RechargeModal from '@/components/finance/RechargeModal';
import { useAuthStore } from '@/stores/authStore';
import { useSubTheme } from '@/hooks/use-subtheme';

function isFullScreenPath(pathname: string) {
  return pathname === '/documentacao/api' || 
         pathname.startsWith('/documentacao/api/') || 
         pathname === '/admin/templates-drawer';
}

export default function AuthenticatedLayout() {
  const { hydrated, isAuthenticated } = useAuthStore();
  const { pathname } = useLocation();
  const hideTopBar = isFullScreenPath(pathname);
  const isTemplatesDrawer = pathname === '/admin/templates-drawer';

  if (!hydrated) {
    if (isTemplatesDrawer) {
      return null;
    }
    return (
      <div className="flex h-screen items-center justify-center bg-background">
        <div
          className="h-9 w-9 rounded-full border-2 border-muted-foreground/25 border-t-primary animate-spin"
          aria-hidden
        />
      </div>
    );
  }

  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }

  const { subTheme } = useSubTheme();

  return (
    <div className="flex h-screen overflow-hidden bg-background relative font-sans">
      {/* Luzes de fundo estilo Compozy (adaptadas para nosso azul) e grade técnica */}
      <div className="absolute inset-0 -z-10 pointer-events-none overflow-hidden" aria-hidden="true">
        <div className="absolute top-[-10%] left-[-10%] w-[45%] h-[45%] bg-[radial-gradient(circle_at_center,hsla(212,95%,56%,0.045),transparent_65%)]" />
        <div className="absolute bottom-[-15%] right-[10%] w-[55%] h-[55%] bg-[radial-gradient(circle_at_center,hsla(212,95%,56%,0.025),transparent_70%)]" />
        <div className="absolute inset-0 compozy-grid-bg opacity-[0.25] dark:opacity-100" />
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,transparent_50%,hsl(var(--background))_98%)]" />
      </div>

      <RechargeModal />
      <AppSidebar />
      <div className="flex-1 flex flex-col overflow-hidden relative min-w-0 bg-transparent">
        {!hideTopBar && <TopBar />}
        {hideTopBar ? (
          <main className={isTemplatesDrawer ? "flex-1 min-h-0" : "flex-1 min-h-0 overflow-y-auto scrollbar-thin"}>
            <div className={isTemplatesDrawer ? "h-full w-full relative overflow-hidden" : "p-3 lg:p-4"}>
              <Outlet />
            </div>
          </main>
        ) : (
          <main className="flex-1 overflow-y-auto scrollbar-thin">
            <div className="p-4 lg:p-5">
              <Outlet />
            </div>
          </main>
        )}
      </div>
    </div>
  );
}
